# Godot-VCSExportPlatform

A super simple export plugin for godot that allows for source code to be coppied to another directory and optionally compressed. Usefull for making automatic source code exports. Requires the NovaTools plugin as a dependency and some sort of VCS plugin to use in the first place.
